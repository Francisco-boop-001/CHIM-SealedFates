# Recovery changes and playtest boundaries

Failed or expired reactions no longer permanently silence eligible senders. Bounded recovery validates current scope, restore and anchors without resending ambiguous operations. Abandoned autonomy claims become terminal on a later fresh eligible request. Due queued children can dispatch without constructing a new model.

Unverifiable terminal reactions stay inert. A scan-progress marker rotates candidates without granting authority; old sources are not exposed or retried. After normal cooldowns the sender can start an independent new root. In-transit mail, active claims and arrived mail without a terminal reaction remain pending. Lost proof is not restored.

Eligible forwards keep the whole attributed original byte for byte. Forward/mediation is offered only if original, labels and cover fit the existing 2000-codepoint/8000-byte body limits. No clipping. Recipient dialogue gets the newest three valid letters from a bounded recent window. Letter claims remain claims, not proven authorship.

Read-only views avoid the writer eventlog lock. Catalog caches last one transaction; effects freshly lock/revalidate selected participants. Renamed-actor letters remain visible as identity_changed with effects disabled. SQL dispatch staging uses a savepoint; filesystem and real inventory effects are not proven atomic.

Suggested isolated Skyrim trial: check an ordinary letter/receipt, NPC-to-NPC initiation/reply without PC dialogue, whole forward/addressed exposure, then save/load and duplicate prevention. For transfers compare both inventories and note. Isolate game saves separately from the server. Automated failure tests used actual PostgreSQL and controlled model callbacks, not fresh provider calls or gameplay.
