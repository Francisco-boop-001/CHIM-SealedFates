# Disposable installation and removal

Install this ZIP as one MO2 mod in a separately verified disposable profile. It supplies Scripts/CHIMCorrespondenceBridge.pex and CHIM/server-plugins/<internal_name>/. Keep only this reviewed bridge active. Use CHIM's supported schema-4 plugin-manager route to install the three pinned packages. The official-manager fixture verified all 90 payload files. The bridge is compiled; Skyrim gameplay is unverified.

Installed layout: ext/correspondence/manifest.json and ext/correspondence/lib/*.php, with no server/ subdirectory. Internal identity stays correspondence. Autonomous correspondence is off by default. Participating NPCs need Background Life and Letters enabled; goals provide a reason to initiate. Consumers retain their own enable/settings rules.

For removal, pause supported features, quiesce the server/game and back up code, data and co-saves. The inspected manager has no verified uninstall method. Remove only exact plugin-owned code after comparing its package, and disable its MO2 bridge separately. Tables, eventlog/evidence anchors, books, PNGs, plugin logs, co-saves and inventory changes may remain. No automatic data deletion or rollback is provided. Do not prune anchors/evidence during code cleanup.

Raw core provider logs can contain private letters/prompts. Ordinary diagnostics use allowlisted codes and bounded timing/IDs; check durable ledgers for committed effects. Do not post raw traces in support reports.
