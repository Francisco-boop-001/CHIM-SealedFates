# Sealed Fates recovery playtest kit

Development candidate 0.1.0-dev.14. Use only a disposable server and separately isolated MO2 test profile. No live installation was performed.

- [Install and removal](docs/INSTALL-REMOVE.md)
- [Changes and checks](docs/RECOVERY.md)
- [Versions and verification limits](evidence/verification-summary.json)

Scripts/ contains the anonymous compiled bridge. CHIM/server-plugins/ contains the exact three tested schema-4 packages. No raw provider traces, private audit or identifying compiler headers are included.
